Set up a variable called "isWaiting" and
initialise it to false.

Add an if statement inside the attack function which
wraps all of the existing code in that function.
Set it so that code only runs when isWaiting is false.

Now set isWaiting to true whenever you want to stop 
a user's ability to press attack.

Remember to set isWaiting to false whenever you want
a user to regain the ability to press attack. 